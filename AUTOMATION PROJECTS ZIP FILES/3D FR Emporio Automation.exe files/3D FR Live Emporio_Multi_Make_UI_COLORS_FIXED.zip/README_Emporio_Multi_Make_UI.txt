IZMO EMPORIO MULTI-MAKE VALIDATOR
=================================

This package contains the updated desktop UI for the Emporio validator.

WHAT IS INCLUDED
----------------
- Emporio_Multi_Make_UI.py   -> UI + embedded validator
- build_emporio_ui.bat       -> one-click Windows EXE builder
- requirements_emporio_ui.txt
- input_template.xlsx

UI FEATURES
-----------
1. Input Excel with two columns:
      Make | url

2. All unique makes from the Excel are shown in the UI.

3. Select All / Clear All / individual make selection.

4. Reload Input button.

5. Run Selected Makes.

6. Pause / Resume.

7. Stop.

8. Model validation progress percentage.

9. Excel generation progress percentage.

10. Individual Excel output for every make.

11. Final merged Excel containing all selected makes.

12. Live activity log and current Make / URL / Model information.

OUTPUT
------
Emporio_Output\YYYYMMDD_HHMMSS\

  <Make>\
      <Make>_Output.xlsx
      URL_Results\
          url_001\
          url_002\
          ...

  Merged_Output\
      ALL_MAKES_MERGED.xlsx

BUILD THE SINGLE EXE
--------------------
1. Windows + Python 3.11 recommended.
2. Put all files in one folder.
3. Double-click build_emporio_ui.bat.
4. The EXE will be created at:
      dist\IZMO_Emporio_Multi_Make_UI.exe

The validator is embedded into the application. You do not need to distribute
its separate .py file.

DEPENDENCY FIX
--------------
The validator is executed dynamically from an embedded Python source string.
Therefore normal static PyInstaller analysis cannot see imports such as
requests and Selenium. The updated UI explicitly imports these packages and
the build script also supplies hidden-import options. This fixes the
"ModuleNotFoundError: No module named 'requests'" error seen in older builds.

RUNTIME REQUIREMENT
-------------------
Google Chrome/Chromium must be installed on the Windows machine because the
validator uses Selenium Chrome WebDriver.
