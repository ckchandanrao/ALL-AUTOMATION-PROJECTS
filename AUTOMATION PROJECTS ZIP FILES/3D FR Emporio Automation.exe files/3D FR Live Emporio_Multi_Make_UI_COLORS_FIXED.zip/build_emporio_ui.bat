@echo off
setlocal
cd /d "%~dp0"

echo ============================================================
echo IZMO Emporio Multi-Make Validator - Windows EXE Build
echo ============================================================
echo.

echo [1/4] Installing/updating required packages...
py -m pip install --upgrade pip
if errorlevel 1 goto :fail
py -m pip install -r requirements_emporio_ui.txt
if errorlevel 1 goto :fail

echo.
echo [2/4] Checking required Python modules...
py -c "import requests, selenium, openpyxl, psutil; print('All required modules are available.')"
if errorlevel 1 goto :fail

echo.
echo [3/4] Building single EXE...
py -m PyInstaller --noconfirm --clean --onefile --windowed ^
 --name IZMO_Emporio_Multi_Make_UI ^
 --hidden-import=requests ^
 --hidden-import=selenium ^
 --hidden-import=selenium.webdriver.chrome.webdriver ^
 --hidden-import=selenium.webdriver.remote.webdriver ^
 --hidden-import=selenium.webdriver.common.service ^
 --hidden-import=selenium.webdriver.common.by ^
 --hidden-import=selenium.webdriver.common.action_chains ^
 --hidden-import=selenium.webdriver.chrome.options ^
 --hidden-import=selenium.webdriver.support.ui ^
 --hidden-import=selenium.webdriver.support.wait ^
 --hidden-import=selenium.common.exceptions ^
 --collect-submodules=selenium ^
 --collect-all=selenium ^
 --hidden-import=openpyxl ^
 --hidden-import=psutil ^
 Emporio_Multi_Make_UI.py
if errorlevel 1 goto :fail

echo.
echo [4/4] Build complete.
echo.
echo EXE:
echo %CD%\dist\IZMO_Emporio_Multi_Make_UI.exe
echo.
echo IMPORTANT: Chrome/Edge must be installed on the machine running the EXE.
echo.
pause
exit /b 0

:fail
echo.
echo ============================================================
echo BUILD FAILED - see the error above.
echo ============================================================
pause
exit /b 1
