IZMO Emporio Multi-Make Validator - Accuracy/Explicit-Wait Build

Included:
- emporio_multi_make_runner.py
- emporio_validator_optimized.py
- input.xlsx
- build_exe.bat

Core behavior preserved:
- Input Excel uses Make and Url columns.
- Select multiple makes from the UI.
- Pause / Resume / Stop are supported.
- Individual URL Excel files are timestamped.
- One timestamped Excel is generated for each completed Make.
- One final timestamped Excel merges the completed Make outputs.
- Base Trim formatting from the validator is preserved when workbooks are merged.

Data-quality improvements:
- Default Color uses an interruptible explicit wait and a selected-swatch fallback.
- Colors are rediscovered from the live DOM on every poll.
- Duplicate color names are removed before counting.
- A color count of 0 is NEVER treated as valid.
- A positive color list must stabilize before it is accepted.
- Base-trim colors must be > 0.
- Every trim must have > 0 unique colors before the model is accepted.
- If required model data is missing, the current model is reloaded and retried up to 3 times.
- A model with required missing data is not written as a fake/blank successful model.
- Trim selection is confirmed by the vehicle header before color/accessory extraction.

Excel progress behavior:
- Excel progress advances by completed Make.
- 2 selected Makes: first Make = 50%, final merged Excel = 100%.
- 3 selected Makes: first = 33.3%, second = 66.7%, final merged Excel = 100%.
- The Excel bar reaches 100% only after the final merged workbook is successfully saved.

Output:
outputs/
  Individual/
    <Make>_<YYYYMMDD_HHMMSS>_<index>.xlsx
  Makes/
    <Make>_Output_<YYYYMMDD_HHMMSS>.xlsx
  IZMO_Emporio_All_Selected_Makes_<YYYYMMDD_HHMMSS>.xlsx

Build on Windows:
1. Put input.xlsx beside the source files.
2. Delete old build and dist folders.
3. Run build_exe.bat.
4. The EXE is created at:
   dist\IZMO_Emporio_Multi_Make_Optimized.exe

The build script explicitly collects Selenium and its dependencies for the one-file EXE.
