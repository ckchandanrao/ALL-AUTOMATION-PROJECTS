IZMO Emporio Multi-Make Validator - Pause/Resume/Stop

Included:
- emporio_multi_make_runner.py
- emporio_validator_optimized.py
- input.xlsx
- build_exe.bat

Controls:
- Pause: pauses validation at the next safe polling point; button changes to Resume.
- Resume: continues validation.
- Stop: stops the active validation as quickly as the current Selenium operation permits,
  prevents new models/URLs from starting, and saves all completed data.
- Validation progress reaches 100% only after all selected validation work is complete.
- Excel generation progress reaches 100% only after the Excel file is successfully saved.

Output:
outputs/
  Individual/
    <Make>_<YYYYMMDD_HHMMSS>_<index>.xlsx
  IZMO_Emporio_All_Selected_Makes_<YYYYMMDD_HHMMSS>.xlsx

The old _individual_runs folder is no longer used. The application also removes a
legacy _individual_runs folder from older versions when a new run is started.

The validator uses verify=False for the internal/test-site URL validation requests
to accommodate the self-signed certificate environment discussed previously.

Build on Windows:
1. Put input.xlsx beside the source files.
2. Run build_exe.bat.
3. The EXE is created at:
   dist\IZMO_Emporio_Multi_Make_Optimized.exe


ACCURACY-FIRST UPDATE FOR 10-12 MAKES
--------------------------------------
- Selected makes are processed sequentially (one active Chrome validation at a time).
- Each URL is allowed up to 3 complete validation attempts.
- Each retry starts from a fresh temporary session to avoid stale DOM/data.
- A generated Excel file is NOT accepted as successful if required data is incomplete.
- Validation Results models must have a Default Color and a positive Number of Trims.
- Every Colors-sheet model row must have Colors Count > 0 and non-blank Color Names.
- If the quality gate fails, the URL is retried instead of being merged.
- Only quality-passed individual files are included in the final merged workbook.
- Color extraction accepts a positive count (>0), but requires the same positive
  count to be observed twice before accepting it.
- Zero colors are never treated as valid data.
