@echo off
setlocal
echo ================================================
echo IZMO Emporio - Optimized Multi-Make EXE Build
echo ================================================
echo.

py -m pip install --upgrade pyinstaller openpyxl selenium requests

if errorlevel 1 (
    echo.
    echo ERROR: Package installation failed.
    pause
    exit /b 1
)

echo.
echo Building EXE...

pyinstaller --noconfirm --clean --onefile --windowed ^
 --name "IZMO_Emporio_Multi_Make_Optimized" ^
 --add-data "emporio_validator_optimized.py;." ^
 --collect-all selenium ^
 --collect-all openpyxl ^
 --hidden-import requests ^
 --hidden-import urllib3 ^
 --hidden-import certifi ^
 --hidden-import charset_normalizer ^
 --hidden-import idna ^
 emporio_multi_make_runner.py

if errorlevel 1 (
    echo.
    echo ERROR: EXE build failed.
    pause
    exit /b 1
)

echo.
echo ================================================
echo BUILD SUCCESSFUL
echo.
echo EXE:
echo dist\IZMO_Emporio_Multi_Make_Optimized.exe
echo ================================================
pause
