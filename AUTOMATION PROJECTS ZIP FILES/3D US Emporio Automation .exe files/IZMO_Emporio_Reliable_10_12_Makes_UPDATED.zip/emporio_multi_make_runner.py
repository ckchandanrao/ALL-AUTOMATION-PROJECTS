import os
import sys
import runpy
import traceback
import threading
import json
import io
import contextlib
import re
import tempfile
from copy import copy
import shutil
from pathlib import Path
from datetime import datetime
import tkinter as tk
from tkinter import ttk, messagebox

import openpyxl
import requests  # Force PyInstaller to bundle requests used by the bundled validator


APP_DIR = Path(sys.executable).resolve().parent if getattr(sys, "frozen", False) else Path(__file__).resolve().parent
INPUT_FILE = APP_DIR / "input.xlsx"
OUTPUT_DIR = APP_DIR / "outputs"
CONTROL_FILE = OUTPUT_DIR / "emporio_control.json"

REQUIRED_COLUMNS = ["Make", "Url"]
SHEETS = ["Validation Results", "Main", "Accessories", "Colors"]

# Accuracy-first settings. A URL is retried as a whole when the generated
# workbook contains incomplete required data. Processing stays sequential so
# 10-12 selected makes do not overload the Emporio site.
MAX_VALIDATION_ATTEMPTS = 3


def clean_filename(value):
    value = re.sub(r'[\\/:*?"<>|]+', "_", str(value or "").strip())
    return value or "Make"


def load_input():
    if not INPUT_FILE.exists():
        raise FileNotFoundError(
            f"input.xlsx not found.\n\nPlace input.xlsx beside the EXE:\n{INPUT_FILE}"
        )

    wb = openpyxl.load_workbook(INPUT_FILE, data_only=False)
    if "input" not in wb.sheetnames:
        raise ValueError('input.xlsx must contain a sheet named "input".')

    ws = wb["input"]
    headers = [str(c.value).strip() if c.value is not None else "" for c in ws[1]]

    missing = [c for c in REQUIRED_COLUMNS if c not in headers]
    if missing:
        raise ValueError("Missing columns in input sheet: " + ", ".join(missing))

    make_col = headers.index("Make") + 1
    url_col = headers.index("Url") + 1

    rows = []
    for r in range(2, ws.max_row + 1):
        make = ws.cell(r, make_col).value
        url = ws.cell(r, url_col).value
        if make is None and url is None:
            continue
        make = str(make or "").strip()
        url = str(url or "").strip()
        if make and url:
            rows.append({"Make": make, "Url": url})

    return rows


def make_result_file(temp_dir, url):
    """The validator names its output from the URL hostname."""
    from urllib.parse import urlparse
    slug = re.sub(r"[^a-zA-Z0-9]+", "_", urlparse(url).netloc).strip("_") or "emporio"
    candidates = sorted(temp_dir.glob(f"emporio_validation_results_{slug}_*.xlsx"), key=lambda p: p.stat().st_mtime, reverse=True)
    if candidates:
        return candidates[0]
    return temp_dir / f"emporio_validation_results_{slug}.xlsx"


def run_validator(url, temp_dir, log_func, progress_callback=None):
    validator_path = Path(getattr(sys, "_MEIPASS", APP_DIR)) / "emporio_validator_optimized.py"
    if not validator_path.exists():
        validator_path = APP_DIR / "emporio_validator_optimized.py"

    old_argv = sys.argv[:]
    old_cwd = Path.cwd()

    class TeeOutput(io.TextIOBase):
        def write(self, text):
            if text:
                for line in text.splitlines():
                    if line.strip():
                        log_func(line.rstrip())
            return len(text)
        def flush(self):
            pass

    stop_monitor = threading.Event()

    def monitor_progress():
        progress_file = temp_dir / "emporio_progress.json"
        last = None
        while not stop_monitor.is_set():
            try:
                if progress_file.exists():
                    data = json.loads(progress_file.read_text(encoding="utf-8"))
                    key = json.dumps(data, sort_keys=True)
                    if key != last:
                        last = key
                        if progress_callback:
                            progress_callback(data)
            except Exception:
                pass
            stop_monitor.wait(0.15)

    monitor = threading.Thread(target=monitor_progress, daemon=True)
    monitor.start()

    try:
        temp_dir.mkdir(parents=True, exist_ok=True)
        os.chdir(temp_dir)
        # Reset control state for this validator invocation.
        (temp_dir / "emporio_control.json").write_text(json.dumps({"action": "run"}), encoding="utf-8")
        sys.argv = [str(validator_path), url]

        log_func(f"Starting validation: {url}")

        try:
            with contextlib.redirect_stdout(TeeOutput()), contextlib.redirect_stderr(TeeOutput()):
                runpy.run_path(str(validator_path), run_name="__main__")
        except SystemExit as exc:
            log_func(f"Validator exited with code: {exc.code}")

        result = make_result_file(temp_dir, url)
        if result.exists():
            log_func(f"Excel generated: {result.name}")
            if progress_callback:
                progress_callback({"phase": "excel", "current": 1, "total": 1, "model": "", "detail": "Excel generated"})
            return result

        files = sorted(temp_dir.glob("*.xlsx"), key=lambda x: x.stat().st_mtime, reverse=True)
        if files:
            log_func(f"Excel generated: {files[0].name}")
            if progress_callback:
                progress_callback({"phase": "excel", "current": 1, "total": 1, "model": "", "detail": "Excel generated"})
            return files[0]

        raise FileNotFoundError("Validator completed but no Excel result was generated.")

    finally:
        stop_monitor.set()
        monitor.join(timeout=1)
        sys.argv = old_argv
        os.chdir(old_cwd)

def copy_cell_style_safe(src, dst):
    """Copy an openpyxl cell style without allowing a StyleArray issue to abort Excel generation."""
    try:
        if getattr(src, "has_style", False):
            dst._style = copy(src._style)
    except Exception:
        # Fall back to individual style components if the workbook contains
        # a style object that cannot be copied as a StyleArray.
        for attr in ("font", "fill", "border", "alignment", "protection"):
            try:
                setattr(dst, attr, copy(getattr(src, attr)))
            except Exception:
                pass
    try:
        dst.number_format = src.number_format
    except Exception:
        pass


def append_sheet(master_ws, source_ws, make_name):
    # First run: copy the complete sheet including header and values/styles.
    if master_ws.max_row == 1 and all(master_ws.cell(1, c).value is None for c in range(1, master_ws.max_column + 1)):
        pass

    source_max_col = source_ws.max_column
    source_max_row = source_ws.max_row

    # Determine whether master already has a header.
    master_has_header = master_ws.max_row >= 1 and any(
        master_ws.cell(1, c).value is not None for c in range(1, master_ws.max_column + 1)
    )

    if not master_has_header:
        for c in range(1, source_max_col + 1):
            sc = source_ws.cell(1, c)
            mc = master_ws.cell(1, c, sc.value)
            copy_cell_style_safe(sc, mc)
        start_row = 2
    else:
        start_row = 2

    # Build master header map.
    headers = {}
    for c in range(1, master_ws.max_column + 1):
        value = master_ws.cell(1, c).value
        if value is not None:
            headers[str(value).strip()] = c

    source_headers = {}
    for c in range(1, source_max_col + 1):
        value = source_ws.cell(1, c).value
        if value is not None:
            source_headers[str(value).strip()] = c

    # Ensure all source columns exist in master.
    for h in source_headers:
        if h not in headers:
            new_c = master_ws.max_column + 1
            master_ws.cell(1, new_c, h)
            headers[h] = new_c

    # Append rows by matching column names.
    for r in range(2, source_max_row + 1):
        # Skip completely empty rows.
        if not any(source_ws.cell(r, c).value is not None for c in range(1, source_max_col + 1)):
            continue

        target_r = master_ws.max_row + 1
        for h, source_c in source_headers.items():
            target_c = headers[h]
            sc = source_ws.cell(r, source_c)
            mc = master_ws.cell(target_r, target_c, sc.value)

            copy_cell_style_safe(sc, mc)
            mc.protection = copy(sc.protection)

        # Add a Make column only if the source sheet does not already contain one.
        if "Make" not in source_headers:
            if "Make" not in headers:
                new_c = master_ws.max_column + 1
                master_ws.cell(1, new_c, "Make")
                headers["Make"] = new_c
            master_ws.cell(target_r, headers["Make"], make_name)


def create_master(results, log_func, master_file, progress_callback=None):
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    if master_file.exists():
        master_file.unlink()

    master = openpyxl.Workbook()
    # Remove default sheet; create required sheets in exact order.
    default = master.active
    master.remove(default)
    for name in SHEETS:
        master.create_sheet(name)

    used = {name: False for name in SHEETS}

    total_sources = max(1, len(results))
    for source_index, (make_name, result_file) in enumerate(results, 1):
        log_func(f"Merging {make_name} -> {result_file.name}")
        if progress_callback:
            progress_callback(((source_index - 1) / total_sources) * 100.0, f"Merging {make_name}...")
        wb = openpyxl.load_workbook(result_file, data_only=False)

        for sheet_name in SHEETS:
            if sheet_name not in wb.sheetnames:
                continue

            src_ws = wb[sheet_name]
            dst_ws = master[sheet_name]

            # First source: copy header, rows, dimensions and basic formatting.
            if not used[sheet_name]:
                # Clear placeholder sheet.
                for row in dst_ws.iter_rows():
                    for cell in row:
                        cell.value = None

                # Copy column widths.
                for key, dim in src_ws.column_dimensions.items():
                    dst_ws.column_dimensions[key].width = dim.width

                # Copy header and all data.
                for row in src_ws.iter_rows():
                    for sc in row:
                        mc = dst_ws.cell(sc.row, sc.column, sc.value)
                        if sc.has_style:
                            mc._style = copy(sc._style)
                        mc.number_format = sc.number_format
                        mc.font = copy(sc.font)
                        mc.fill = copy(sc.fill)
                        mc.border = copy(sc.border)
                        mc.alignment = copy(sc.alignment)
                        mc.protection = copy(sc.protection)

                used[sheet_name] = True
            else:
                append_sheet(dst_ws, src_ws, make_name)

        wb.close()

    # Freeze headers and autofilter where possible.
    for ws in master.worksheets:
        if ws.max_row >= 1 and ws.max_column >= 1:
            ws.freeze_panes = "A2"
            ws.auto_filter.ref = ws.dimensions

    if progress_callback:
        progress_callback(96.0, "Saving combined Excel...")
    master.save(master_file)
    if progress_callback:
        progress_callback(100.0, "Combined Excel generated successfully")
    return master_file


def validate_excel_completeness(path):
    """Post-run safety gate: reject incomplete required model/color data."""
    issues = []
    try:
        wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
    except Exception as exc:
        return False, [f"Could not open generated workbook: {exc}"]

    try:
        missing = set(SHEETS).difference(wb.sheetnames)
        if missing:
            return False, [f"Missing sheets: {', '.join(sorted(missing))}"]

        ws = wb["Validation Results"]
        header_row = next(ws.iter_rows(min_row=1, max_row=1))
        headers = [str(c.value or "").strip() for c in header_row]
        pos = {h: i for i, h in enumerate(headers)}

        for col in ["Year", "Make", "Model", "Number of Trims", "Default Color"]:
            if col not in pos:
                issues.append(f"Validation Results missing column: {col}")
        if issues:
            return False, issues

        model_keys = []
        for row in ws.iter_rows(min_row=2, values_only=True):
            model = str(row[pos["Model"]] or "").strip()
            if not model:
                continue
            year = str(row[pos["Year"]] or "").strip()
            make = str(row[pos["Make"]] or "").strip()
            key = (year.casefold(), make.casefold(), model.casefold())
            model_keys.append(key)

            if not str(row[pos["Default Color"]] or "").strip():
                issues.append(f"{year} {make} {model}: Default Color is blank")

            try:
                trim_count = int(row[pos["Number of Trims"]] or 0)
            except Exception:
                trim_count = 0
            if trim_count <= 0:
                issues.append(f"{year} {make} {model}: Number of Trims is 0")

        if not model_keys:
            issues.append("Validation Results contains no completed models")
            return False, issues

        cws = wb["Colors"]
        cheaders = [str(c.value or "").strip() for c in next(cws.iter_rows(min_row=1, max_row=1))]
        cpos = {h: i for i, h in enumerate(cheaders)}
        for col in ["Year", "Make", "Model", "Colors Count", "Color Names"]:
            if col not in cpos:
                issues.append(f"Colors missing column: {col}")
        if any(col not in cpos for col in ["Year", "Make", "Model", "Colors Count", "Color Names"]):
            return False, issues

        color_map = {}
        for row in cws.iter_rows(min_row=2, values_only=True):
            model = str(row[cpos["Model"]] or "").strip()
            if not model:
                continue
            year = str(row[cpos["Year"]] or "").strip()
            make = str(row[cpos["Make"]] or "").strip()
            key = (year.casefold(), make.casefold(), model.casefold())
            color_map.setdefault(key, 0)
            try:
                count = int(row[cpos["Colors Count"]] or 0)
            except Exception:
                count = 0
            names = str(row[cpos["Color Names"]] or "").strip()
            if count <= 0 or not names:
                issues.append(f"{year} {make} {model}: Colors sheet has 0/blank colors")
            else:
                color_map[key] += 1

        for key in model_keys:
            if color_map.get(key, 0) <= 0:
                issues.append(f"{key[1]} {key[2]}: no valid Colors-sheet row")

        unique = []
        seen = set()
        for item in issues:
            if item not in seen:
                seen.add(item)
                unique.append(item)
        return len(unique) == 0, unique[:20]
    finally:
        wb.close()


class App:
    def __init__(self, root):
        self.root = root
        self.root.title("IZMO Emporio - Multi Make Validator")
        self.root.geometry("900x650")
        self.root.minsize(760, 520)

        self.rows = []
        self.make_map = {}
        self.active_control_file = None
        self.run_stamp = None

        self.build_ui()
        self.reload_input()

    def build_ui(self):
        # Modern dark UI built only with Tkinter/ttk (no external GUI dependency).
        self.root.configure(bg="#0b1220")

        style = ttk.Style(self.root)
        try:
            style.theme_use("clam")
        except Exception:
            pass

        style.configure("App.TFrame", background="#0b1220")
        style.configure("Card.TFrame", background="#111827")
        style.configure("Title.TLabel", background="#0b1220", foreground="#f8fafc",
                        font=("Segoe UI", 20, "bold"))
        style.configure("Sub.TLabel", background="#0b1220", foreground="#94a3b8",
                        font=("Segoe UI", 10))
        style.configure("CardTitle.TLabel", background="#111827", foreground="#e5e7eb",
                        font=("Segoe UI", 10, "bold"))
        style.configure("Status.TLabel", background="#111827", foreground="#cbd5e1",
                        font=("Segoe UI", 10))
        style.configure("Run.TButton", font=("Segoe UI", 10, "bold"), padding=(16, 8))
        style.configure("Stop.TButton", font=("Segoe UI", 10, "bold"), padding=(16, 8))
        style.configure("Pause.TButton", font=("Segoe UI", 10, "bold"), padding=(16, 8))
        style.configure("Validation.Horizontal.TProgressbar", troughcolor="#1e293b",
                        background="#22c55e", lightcolor="#4ade80", darkcolor="#16a34a",
                        thickness=18)
        style.configure("Excel.Horizontal.TProgressbar", troughcolor="#1e293b",
                        background="#38bdf8", lightcolor="#7dd3fc", darkcolor="#0284c7",
                        thickness=18)

        outer = ttk.Frame(self.root, style="App.TFrame", padding=18)
        outer.pack(fill="both", expand=True)

        ttk.Label(outer, text="IZMO Emporio Validator", style="Title.TLabel").pack(anchor="w")
        ttk.Label(
            outer,
            text="Multi-make validation • live progress • pause/resume • safe stop • timestamped Excel",
            style="Sub.TLabel"
        ).pack(anchor="w", pady=(2, 14))

        controls_card = ttk.Frame(outer, style="Card.TFrame", padding=12)
        controls_card.pack(fill="x", pady=(0, 10))

        ttk.Button(controls_card, text="↻ Reload", command=self.reload_input).pack(side="left", padx=(0, 6))
        ttk.Button(controls_card, text="Select All", command=self.select_all).pack(side="left", padx=6)
        ttk.Button(controls_card, text="Clear", command=self.clear_selection).pack(side="left", padx=6)

        self.run_button = ttk.Button(
            controls_card, text="▶  Run Selected Makes", style="Run.TButton", command=self.start_run
        )
        self.run_button.pack(side="right", padx=(6, 0))

        self.pause_button = ttk.Button(
            controls_card, text="Ⅱ  Pause", style="Pause.TButton", command=self.toggle_pause, state="disabled"
        )
        self.pause_button.pack(side="right", padx=6)

        self.stop_button = ttk.Button(
            controls_card, text="■  Stop", style="Stop.TButton", command=self.request_stop, state="disabled"
        )
        self.stop_button.pack(side="right", padx=6)

        list_card = ttk.Frame(outer, style="Card.TFrame", padding=12)
        list_card.pack(fill="both", expand=True, pady=(0, 10))
        ttk.Label(list_card, text="Available Makes", style="CardTitle.TLabel").pack(anchor="w", pady=(0, 7))

        list_frame = ttk.Frame(list_card, style="Card.TFrame")
        list_frame.pack(fill="both", expand=True)

        self.listbox = tk.Listbox(
            list_frame, selectmode=tk.EXTENDED, font=("Segoe UI", 11),
            activestyle="none", bg="#0f172a", fg="#e5e7eb",
            selectbackground="#2563eb", selectforeground="#ffffff",
            relief="flat", borderwidth=0, highlightthickness=1,
            highlightbackground="#334155", highlightcolor="#3b82f6"
        )
        self.listbox.pack(side="left", fill="both", expand=True)

        scrollbar = ttk.Scrollbar(list_frame, orient="vertical", command=self.listbox.yview)
        scrollbar.pack(side="right", fill="y")
        self.listbox.config(yscrollcommand=scrollbar.set)

        progress_card = ttk.Frame(outer, style="Card.TFrame", padding=14)
        progress_card.pack(fill="x", pady=(0, 10))

        self.progress_label = ttk.Label(
            progress_card, text="Validation Progress   0%  •  Ready", style="Status.TLabel"
        )
        self.progress_label.pack(anchor="w", pady=(0, 6))

        self.progress = ttk.Progressbar(
            progress_card, orient="horizontal", mode="determinate",
            maximum=100, value=0, style="Validation.Horizontal.TProgressbar"
        )
        self.progress.pack(fill="x", ipady=3)

        self.excel_progress_label = ttk.Label(
            progress_card, text="Excel Generation   0%  •  Waiting", style="Status.TLabel"
        )
        self.excel_progress_label.pack(anchor="w", pady=(12, 6))

        self.excel_progress = ttk.Progressbar(
            progress_card, orient="horizontal", mode="determinate",
            maximum=100, value=0, style="Excel.Horizontal.TProgressbar"
        )
        self.excel_progress.pack(fill="x", ipady=3)

        self.detail_label = ttk.Label(
            progress_card, text="Select one or more makes and start validation.",
            style="Status.TLabel"
        )
        self.detail_label.pack(anchor="w", pady=(9, 0))

        status_card = ttk.Frame(outer, style="Card.TFrame", padding=10)
        status_card.pack(fill="both", expand=False)
        ttk.Label(status_card, text="Run Log", style="CardTitle.TLabel").pack(anchor="w", pady=(0, 5))

        self.status = tk.Text(
            status_card, height=7, wrap="word", state="disabled",
            bg="#0f172a", fg="#cbd5e1", insertbackground="#ffffff",
            relief="flat", borderwidth=0, font=("Consolas", 9)
        )
        self.status.pack(fill="both", expand=True)

    def _write_control(self, action):
        try:
            OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
            target = self.active_control_file or CONTROL_FILE
            Path(target).write_text(json.dumps({"action": action}), encoding="utf-8")
        except Exception as exc:
            self.log(f"CONTROL ERROR: {exc}")

    def toggle_pause(self):
        if not getattr(self, "run_active", False) or getattr(self, "stop_requested", False):
            return
        if not getattr(self, "paused", False):
            self.paused = True
            self._write_control("pause")
            self.pause_button.config(text="▶  Resume")
            self.progress_label.config(text=f"{float(self.progress.get()):.1f}%  •  Paused")
            self.detail_label.config(text="PAUSED — validation is waiting. Click Resume to continue.")
            self.log("PAUSED — validation is now waiting for Resume.")
        else:
            self.paused = False
            self._write_control("run")
            self.pause_button.config(text="Ⅱ  Pause")
            self.detail_label.config(text="RESUMED — validation continuing...")
            self.log("RESUMED — validation continuing.")

    def request_stop(self):
        if not getattr(self, "run_active", False) or getattr(self, "stop_requested", False):
            return
        # Set the local flag first so the runner will not start another URL.
        self.stop_requested = True
        # Tell the currently running validator to stop at its next polling point.
        self._write_control("stop")
        self.pause_button.config(state="disabled")
        self.stop_button.config(state="disabled", text="■  Stopping...")
        self.detail_label.config(text="STOP requested — stopping validation and saving completed data...")
        self.log("STOP REQUESTED — no new model/URL will be started; completed data will be saved.")

    def log(self, message):
        def update():
            self.status.config(state="normal")
            self.status.insert("end", message + "\n")
            self.status.see("end")
            self.status.config(state="disabled")
        self.root.after(0, update)

    def update_progress(self, data):
        def update():
            phase = data.get("phase", "")
            current = int(data.get("current", 0) or 0)
            total = int(data.get("total", 0) or 0)
            model = data.get("model", "") or ""
            detail = data.get("detail", "") or ""
            raw_percent = data.get("percent", None)

            if phase in {"validation", "discovery", "model", "step", "model_complete"}:
                if raw_percent is not None:
                    pct = float(raw_percent)
                else:
                    pct = (current / total * 100.0) if total else 0.0
                pct = max(0.0, min(100.0, pct))
                self.progress["value"] = pct
                if model:
                    self.progress_label.config(text=f"Validation Progress   {pct:.1f}%  •  Model {current}/{total}: {model}")
                else:
                    self.progress_label.config(text=f"Validation Progress   {pct:.1f}%  •  {detail or 'Starting'}")
                self.detail_label.config(text=detail or "Validation in progress...")
                return

            if phase in {"excel_generation", "excel"}:
                pct = float(raw_percent if raw_percent is not None else (current / total * 100.0 if total else 0.0))
                pct = max(0.0, min(100.0, pct))
                self.excel_progress["value"] = pct
                self.excel_progress_label.config(text=f"Excel Generation   {pct:.1f}%  •  {detail or 'Generating Excel...'}")
                self.detail_label.config(text=detail or "Generating Excel output...")
                return

            if phase == "stopped":
                if raw_percent is not None:
                    pct = max(0.0, min(100.0, float(raw_percent)))
                    self.progress["value"] = pct
                self.progress_label.config(text=f"Validation Progress   {float(self.progress.get()):.1f}%  •  Stopped")
                self.detail_label.config(text=detail or "Stop requested.")
                return

        self.root.after(0, update)

    def reload_input(self):
        try:
            self.rows = load_input()
            self.make_map = {}
            self.listbox.delete(0, tk.END)

            for row in self.rows:
                make = row["Make"]
                self.make_map.setdefault(make, []).append(row["Url"])

            for make in self.make_map:
                self.listbox.insert(tk.END, make)

            self.log(f"Loaded {len(self.make_map)} Make(s) from input.xlsx.")
        except Exception as exc:
            messagebox.showerror("Input Error", str(exc))
            self.log("ERROR: " + str(exc))

    def select_all(self):
        if self.listbox.size():
            self.listbox.selection_set(0, tk.END)

    def clear_selection(self):
        self.listbox.selection_clear(0, tk.END)

    def start_run(self):
        selected_indices = self.listbox.curselection()
        if not selected_indices:
            messagebox.showwarning("No Make Selected", "Please select at least one Make.")
            return

        selected_makes = [self.listbox.get(i) for i in selected_indices]

        # Remove the legacy user-visible temporary folder from older builds.
        legacy_runs = OUTPUT_DIR / "_individual_runs"
        if legacy_runs.exists():
            try:
                shutil.rmtree(legacy_runs)
            except Exception as exc:
                self.log(f"WARNING: Could not remove legacy _individual_runs folder: {exc}")

        self.run_active = True
        self.paused = False
        self.stop_requested = False
        self._write_control("run")
        self.run_button.config(state="disabled")
        self.pause_button.config(state="normal", text="Ⅱ  Pause")
        self.stop_button.config(state="normal")
        self.progress["value"] = 0
        self.excel_progress["value"] = 0
        self.progress_label.config(text="Validation Progress   0.0%  •  Starting...")
        self.excel_progress_label.config(text="Excel Generation   0.0%  •  Waiting")
        self.log("")
        self.log("=" * 70)
        self.log("RUN STARTED")
        self.log("Selected Makes: " + ", ".join(selected_makes))
        self.log("=" * 70)

        thread = threading.Thread(
            target=self.run_selected,
            args=(selected_makes,),
            daemon=True
        )
        thread.start()

    def _reset_excel_progress_for_master(self):
        self.excel_progress["value"] = 0
        self.excel_progress_label.config(text="Excel Generation   0.0%  •  Building combined workbook...")

    def run_selected(self, selected_makes):
        """Run selected makes using OS temp folders; only user-facing Excel files remain in outputs."""
        successful = []
        failed = []

        run_stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        individual_dir = OUTPUT_DIR / "Individual"
        individual_dir.mkdir(parents=True, exist_ok=True)

        try:
            for index, make in enumerate(selected_makes, 1):
                if self.stop_requested:
                    break
                urls = self.make_map.get(make, [])
                self.log(f"[{index}/{len(selected_makes)}] MAKE: {make}")

                for url_index, url in enumerate(urls, 1):
                    if self.stop_requested:
                        break

                    safe_make = clean_filename(make)
                    # Temporary validator data lives outside the output folder.
                    with tempfile.TemporaryDirectory(prefix="izmo_emporio_") as tmp:
                        temp_dir = Path(tmp)
                        # Set the exact control file before the validator starts so
                        # Pause/Resume/Stop always target the active validation.
                        self.active_control_file = temp_dir / "emporio_control.json"
                        self.active_control_file.write_text(
                            json.dumps({"action": "run"}), encoding="utf-8"
                        )

                        try:
                            result = None
                            last_error = None
                            quality_issues = ["No successful quality check"]

                            for attempt in range(1, MAX_VALIDATION_ATTEMPTS + 1):
                                if self.stop_requested:
                                    break

                                self.log(f"  ATTEMPT {attempt}/{MAX_VALIDATION_ATTEMPTS}: {make} -> {url}")
                                try:
                                    result = run_validator(url, temp_dir, self.log, self.update_progress)
                                    if not result or not result.exists():
                                        raise FileNotFoundError("Validator returned without an Excel result.")

                                    valid, quality_issues = validate_excel_completeness(result)
                                    if valid:
                                        self.log(f"  DATA QUALITY PASS: {make} (attempt {attempt})")
                                        break

                                    last_error = "Incomplete Excel data: " + " | ".join(quality_issues[:8])
                                    self.log(f"  DATA QUALITY FAIL: {last_error}")
                                except Exception as exc:
                                    last_error = str(exc)
                                    quality_issues = [last_error]
                                    self.log(f"  VALIDATION ATTEMPT FAILED: {exc}")
                                    self.log(traceback.format_exc())

                                if attempt < MAX_VALIDATION_ATTEMPTS and not self.stop_requested:
                                    self.log("  Retrying from a fresh temporary session...")
                                    try:
                                        shutil.rmtree(temp_dir, ignore_errors=True)
                                        temp_dir.mkdir(parents=True, exist_ok=True)
                                        self.active_control_file = temp_dir / "emporio_control.json"
                                        self.active_control_file.write_text(
                                            json.dumps({"action": "run"}), encoding="utf-8"
                                        )
                                    except Exception as reset_exc:
                                        last_error = f"Retry reset failed: {reset_exc}"
                                        break

                            if (
                                result and result.exists()
                                and not quality_issues
                                and not self.stop_requested
                            ):
                                individual_name = f"{safe_make}_{run_stamp}_{url_index}.xlsx"
                                individual_path = individual_dir / individual_name
                                if individual_path.exists():
                                    n = 2
                                    stem = individual_path.stem
                                    while (individual_dir / f"{stem}_{n}.xlsx").exists():
                                        n += 1
                                    individual_path = individual_dir / f"{stem}_{n}.xlsx"

                                shutil.copy2(result, individual_path)
                                successful.append((make, individual_path))
                                self.log(f"PASS: {make} | Individual Excel: {individual_path.name}")
                            elif not self.stop_requested:
                                error_text = last_error or "Excel remained incomplete after all retry attempts."
                                failed.append((make, url, error_text))
                                self.log(f"FAIL: {make} -> {error_text}")

                        except Exception as exc:
                            failed.append((make, url, str(exc)))
                            self.log(f"FAIL: {make} -> {exc}")
                            self.log(traceback.format_exc())
                        finally:
                            self.active_control_file = None

                    if self.stop_requested:
                        break

            # Always merge whatever was successfully written, including a partial
            # run after Stop. The combined workbook gets its own timestamp.
            master_file = None
            if successful:
                master_file = OUTPUT_DIR / f"IZMO_Emporio_All_Selected_Makes_{run_stamp}.xlsx"
                self.root.after(0, self._reset_excel_progress_for_master)
                create_master(
                    successful,
                    self.log,
                    master_file,
                    lambda pct, detail: self.update_progress({
                        "phase": "excel_generation",
                        "percent": pct,
                        "detail": detail
                    })
                )
                self.log("=" * 70)
                self.log("ALL AVAILABLE SELECTED-MAKE RESULTS MERGED INTO ONE EXCEL")
                self.log(str(master_file))
                self.log("=" * 70)
            else:
                self.log("No completed validation result was available to merge.")

            was_stopped = self.stop_requested
            summary = (
                ("Stopped safely.\n\n" if was_stopped else "Completed.\n\n")
                + f"Successful: {len(successful)}\n"
                + f"Failed: {len(failed)}\n\n"
            )
            if master_file:
                summary += f"Combined Excel output:\n{master_file}"

            if successful:
                summary += f"\n\nIndividual Excel files:\n{individual_dir}"

            if failed:
                summary += "\n\nFailed Makes:\n" + "\n".join(
                    f"- {m}: {err}" for m, _, err in failed
                )

            self.root.after(0, lambda s=summary: messagebox.showinfo("Validation Complete", s))

        except Exception as exc:
            self.log("RUN ERROR: " + str(exc))
            self.log(traceback.format_exc())
            self.root.after(0, lambda e=str(exc): messagebox.showerror("Run Error", e))
        finally:
            def finish_ui():
                self.run_active = False
                self.paused = False
                self.active_control_file = None
                self.run_button.config(state="normal")
                self.pause_button.config(state="disabled", text="Ⅱ  Pause")
                self.stop_button.config(state="disabled", text="■  Stop")
                if not self.stop_requested:
                    self.progress["value"] = 100.0
                    self.progress_label.config(text="Validation Progress   100.0%  •  Complete")
                # Excel reaches 100 only from create_master after master.save().
            self.root.after(0, finish_ui)



if __name__ == "__main__":
    root = tk.Tk()
    try:
        root.iconname("IZMO Emporio")
    except Exception:
        pass
    App(root)
    root.mainloop()
